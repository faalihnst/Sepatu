<?php

$dbHost = 'localhost';
$dbName = 'fitoshoes';
$dbUsername = 'root';
$dbPassword = '';

$mysqli = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName); 

?>