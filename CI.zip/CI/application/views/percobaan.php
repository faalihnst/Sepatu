<!DOCTYPE html>
<html>
<head>
	<title>Page Title</title>
</head>
<body>
	<table>
		<tr>
			<th>username</th>
			<th>firstname</th>
			<th>password</th>
			<th>email</th>
		</tr>
		<?php foreach($user as $us ){ ?>
		<tr>
			<td><?php echo $us->username ?></td>
			<td><?php echo $us->firstname ?></td>
			<td><?php echo $us->lastname ?></td>
			<td><?php echo $us->email ?></td>
		</tr>
		<?php } ?>
	</table>


</body>
</html>
