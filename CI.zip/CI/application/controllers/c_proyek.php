<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_proyek extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_proyek');
		$this->load->helper('url');
	}
	//percobaan//
	public function percobaan(){
		$data['user']=$this->m_proyek->ambil_data()->result();
		$this->load->view('percobaan',$data);
	}
	//home//
	public function awal(){
		$this->load->view('home');
	}
	//login//
	public function masuk(){
		$this->load->view('login');
	}
	//allshoes//
	public function semua(){
		$this->load->view('allshoes');
	}
	//arrival//
	public function baru(){
		$this->load->view('new');
	}
	//signup//
	public function daftar(){
		$this->load->view('signup');
	}
	//masukin signup//
	public function daftar_tambah(){
		$username=$this->input->post('username');
		$firstname=$this->input->post('firstname');
		$lastname=$this->input->post('lastname');
		$email=$this->input->post('email');
		$data=array('username' => $username, 'firstname' => $firstname, 'lastname' => $lastname, 'email' => $email);
		$this->m_proyek->input_data($data,'user');
		redirect('c_proyek/masuk');
	}
	//order//
	public function pesan(){
		$this->load->view('order');
	}
}

?>